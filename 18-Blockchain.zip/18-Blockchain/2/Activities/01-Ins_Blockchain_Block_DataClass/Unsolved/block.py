# Creating a Blockchain Block with a DataClass
