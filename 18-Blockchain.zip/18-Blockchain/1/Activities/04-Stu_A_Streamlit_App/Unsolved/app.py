# @TODO: Import the libraries for Pandas and Streamlit
# YOUR CODE HERE!

# @TODO: Create a title for your application using markdown syntax and the
# Streamlit `write` function.
# YOUR CODE HERE!

# @TODO: Create an opening sentence for your application using regular text and
# the Streamlit `write` function.
# YOUR CODE HERE!

# @TODO: Create a Pandas dataframe
# YOUR CODE HERE!

# @TODO: Write the Pandas dataframe to the page
# YOUR CODE HERE!

# @TODO: Create a text input box using the Streamlit `text_input` function.
# @TODO: Save the input as a variable.
# YOUR CODE HERE!

# @TODO: Utilize the Streamlit `button` function to display the text input
# variable created in the prior step to the page.
# YOUR CODE HERE!


# Bonus
# YOUR CODE HERE!
